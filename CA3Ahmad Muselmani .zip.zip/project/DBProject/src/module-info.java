/**
 * 
 */
/**
 * @author C00276504
 *
 */
module DBProject {
	requires java.sql;
	requires java.desktop;
}