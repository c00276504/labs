package ie.itcarlow.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Calendar;

public class CRUDJOrders extends JFrame {

    private JLabel iDLabel, cIDLabel, descriptionLabel, dateLabel, quantityLabel;
    private JTextField iDTextField, cIDTextField, descriptionTextField, dateTextField, quantityTextField;
    private JButton findButton, addButton, updateButton, deleteButton;
    private JTable dataTable;
    private JScrollPane scrollPane;
    private Connection connection;
    private PreparedStatement pstat;
    private final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";

    public CRUDJOrders() {
        super("CRUD Operations Orders' Table");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 700);

        // create panel for input fields and buttons
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(7, 4, 10, 10)); // changed to 6 rows to include all labels and textfields

        // create labels and textfields for input
        iDLabel = new JLabel("Enter ID:");
        iDTextField = new JTextField();

        cIDLabel = new JLabel("Customer ID:");
        cIDTextField = new JTextField();

        descriptionLabel = new JLabel("Description:");
        descriptionTextField = new JTextField();

        dateLabel = new JLabel("Order Date:");
        dateTextField = new JTextField();

        quantityLabel = new JLabel("Quantity:");
        quantityTextField = new JTextField();

        // create buttons for CRUD operations
        findButton = new JButton("Find"); // fixed variable name, was addButton before
        findButton.setLocation(50, 50);
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        
        
     // create buttons for CRUD operations
        findButton = new JButton("Find");
        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(iDTextField.getText()); 
                    String query = "SELECT * FROM orders WHERE Order_ID = ?";
                    pstat = connection.prepareStatement(query);
                    pstat.setInt(1, id);
                    ResultSet rs = pstat.executeQuery();
                    if (!rs.next()) {
                        JOptionPane.showMessageDialog(null, "Couldn't find the ID");
                    } else {
                    	cIDTextField.setText(rs.getString("Customer_ID"));
                    	descriptionTextField.setText(rs.getString("Description"));
                    	dateTextField.setText(rs.getString("Order_Date"));
                    	quantityTextField.setText(rs.getString("Quantity"));
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get the data from the input fields
                    int customerID = Integer.parseInt(cIDTextField.getText());
                    String description = descriptionTextField.getText();
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(Date.valueOf(dateTextField.getText())); // January 1, 2023
                    Date orderDate = new Date(calendar.getTime().getTime());
           
                    int quantity = Integer.parseInt(quantityTextField.getText());

                    // create Prepared Statement for inserting data into table
                    pstat = connection.prepareStatement("INSERT INTO orders (Customer_ID, Description, Order_Date, Quantity) VALUES (?,?,?,?)");
                    pstat.setInt(1, customerID);
                    pstat.setString(2, description);
                    pstat.setDate(3, orderDate);
                    pstat.setInt(4, quantity);
                    pstat.executeUpdate();

                    // Clear the input fields
                    cIDTextField.setText("");
                    descriptionTextField.setText("");
                    dateTextField.setText("");
                    quantityTextField.setText("");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
       
        

        updateButton = new JButton("Update");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
			         int id = Integer.parseInt(iDTextField.getText());
					String query = "UPDATE orders SET Customer_ID=?, Description=?, Order_Date=?, Quantity=? WHERE Order_ID=?";
					pstat = connection.prepareStatement(query);
					pstat.setInt(1, Integer.parseInt(cIDTextField.getText()));
					pstat.setString(2, descriptionTextField.getText());
					pstat.setDate(3, Date.valueOf(dateTextField.getText()));
					pstat.setInt(4, Integer.parseInt(quantityTextField.getText()));
					pstat.setInt(5, id);
					int rowsUpdated = pstat.executeUpdate();
					if (rowsUpdated == 0) {
					JOptionPane.showMessageDialog(null, "Couldn't find the ID");
					} else {
					JOptionPane.showMessageDialog(null, "Order with ID " + id + " updated successfully");
					}
					iDTextField.setText("");
					cIDTextField.setText("");
			        descriptionTextField.setText("");
			        dateTextField.setText("");
			        quantityTextField.setText("");
					} catch (SQLException ex) {
					ex.printStackTrace();
					}
				}
			});
        
        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get the ID from the input field
                	int id = Integer.parseInt(iDTextField.getText()); 

                    // create Prepared Statement for deleting data from table
                    pstat = connection.prepareStatement("DELETE FROM orders WHERE Order_ID = ?");
                    pstat.setInt(1, id);
                    pstat.executeUpdate();

                    // Clear the input fields
                    iDTextField.setText("");
                    cIDTextField.setText("");
                    descriptionTextField.setText("");
                    dateTextField.setText("");
                    quantityTextField.setText("");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // add the labels and textfields to the input panel
        inputPanel.add(iDLabel);
        inputPanel.add(iDTextField);
        
        inputPanel.add(cIDLabel);
        inputPanel.add(cIDTextField);
        
        inputPanel.add(descriptionLabel);
        inputPanel.add(descriptionTextField);

        

        inputPanel.add(dateLabel);
        inputPanel.add(dateTextField);

        inputPanel.add(quantityLabel);
        inputPanel.add(quantityTextField);
        
     // add the buttons to the input panel
        inputPanel.add(findButton);
        inputPanel.add(addButton);
        inputPanel.add(updateButton);
        inputPanel.add(deleteButton);


        

        // create a panel for the data table
        JPanel dataPanel = new JPanel(new GridLayout());
        DefaultTableModel model = new DefaultTableModel();
        dataTable = new JTable(model);
        model.addColumn("ID");
        model.addColumn("Customer ID");
        model.addColumn("Description");
        model.addColumn("Order Date");
        model.addColumn("Quantity");

        // create a scroll pane and add the data table to it
        scrollPane = new JScrollPane(dataTable);
        dataPanel.add(scrollPane);

        // add the input panel and data panel to the frame
        add(inputPanel, BorderLayout.NORTH);
        add(dataPanel, BorderLayout.CENTER);

        // connect to the database and populate the data table
        try {
            connection = DriverManager.getConnection(DATABASE_URL, "root", "");
            String query = "SELECT * FROM orders";
            pstat = connection.prepareStatement(query);
            ResultSet rs = pstat.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("Order_ID");
                int customerID = rs.getInt("Customer_ID");
                String description = rs.getString("Description");
                Date orderDate = rs.getDate("Order_Date");
                int quantity = rs.getInt("Quantity");
                

                model.addRow(new Object[]{id, customerID, description, orderDate, quantity});
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        setVisible(true);
        
    }

    public static void main(String[] args) {
    	CRUDJOrders crud = new CRUDJOrders();
    }

}
