package ie.itcarlow.gui;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class CRUDJCustomers extends JFrame {

    private JLabel iDLabel, nameLabel, addressLabel, phoneLabel, emailLabel;
    private JTextField iDTextField, nameTextField, addressTextField, phoneTextField, emailTextField;
    private JButton findButton, addButton, updateButton, deleteButton;
    private JTable dataTable;
    private JScrollPane scrollPane;
    private Connection connection;
    private PreparedStatement pstat;
    private final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";

    public CRUDJCustomers() {
        super("CRUD Operations Customers' Table");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 700);

        // create panel for input fields and buttons
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(8,5, 10, 10));

        // create labels and textfields for input
        iDLabel = new JLabel("Enter ID:");
        iDTextField = new JTextField();

        nameLabel = new JLabel("Customer Name:");
        nameTextField = new JTextField();

        addressLabel = new JLabel("Address:");
        addressTextField = new JTextField();

        phoneLabel = new JLabel("Phone Number:");
        phoneTextField = new JTextField();

        emailLabel = new JLabel("Email:");
        emailTextField = new JTextField();

        // create buttons for CRUD operations
        findButton = new JButton("Find");
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");

        // add action listeners to the buttons
        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // get the ID from the input field
                    int id = Integer.parseInt(iDTextField.getText());

                    // create prepared statement for selecting data from table
                    pstat = connection.prepareStatement("SELECT * FROM customers WHERE Customer_ID = ?");
                    pstat.setInt(1, id);
                    ResultSet rs = pstat.executeQuery();

                    if (!rs.next()) {
                        JOptionPane.showMessageDialog(null, "Couldn't find the ID");
                    } else {
                        nameTextField.setText(rs.getString("Customer_Name"));
                        addressTextField.setText(rs.getString("Address"));
                        phoneTextField.setText(rs.getString("Phone_Number"));
                        emailTextField.setText(rs.getString("Email"));
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // get the data from the input fields
                    String name = nameTextField.getText();
                    String address = addressTextField.getText();
                    String phone = phoneTextField.getText();
                    String email = emailTextField.getText();

                    // create prepared statement for inserting data into table
                    pstat = connection.prepareStatement("INSERT INTO customers (Customer_Name, Address, Phone_Number, Email) VALUES (?, ?, ?, ?)");
                    pstat.setString(1, name);
                    pstat.setString(2, address);
                    pstat.setString(3, phone);
                    pstat.setString(4, email);
                    pstat.executeUpdate();

                    // clear the input fields
                    nameTextField.setText("");
                    addressTextField.setText("");
                    phoneTextField.setText("");
                    emailTextField.setText("");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        updateButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
        try {
        // get the data from the input fields
        int id = Integer.parseInt(iDTextField.getText());
        String name = nameTextField.getText();
        String address = addressTextField.getText();
        String phone = phoneTextField.getText();
        String email = emailTextField.getText();

       

                        // create prepared statement for updating data in the table
                        pstat = connection.prepareStatement("UPDATE customers SET Customer_Name = ?, Address = ?, Phone_Number = ?, Email = ? WHERE Customer_ID = ?");
                        pstat.setString(1, name);
                        pstat.setString(2, address);
                        pstat.setString(3, phone);
                        pstat.setString(4, email);
                        pstat.setInt(5, id);
                        int rowsAffected = pstat.executeUpdate();

                        if (rowsAffected == 0) {
                            JOptionPane.showMessageDialog(null, "Couldn't update the record");
                        } else {
                            JOptionPane.showMessageDialog(null, "Record updated successfully");
                        }

                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            });
        
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // get the ID from the input field
                    int id = Integer.parseInt(iDTextField.getText());

                    // create prepared statement for deleting data from table
                    pstat = connection.prepareStatement("DELETE FROM customers WHERE Customer_ID = ?");
                    pstat.setInt(1, id);
                    int rowsAffected = pstat.executeUpdate();

                    if (rowsAffected == 0) {
                        JOptionPane.showMessageDialog(null, "Couldn't delete the record");
                    } else {
                        JOptionPane.showMessageDialog(null, "Record deleted successfully");
                        // clear the input fields
                        iDTextField.setText("");
                        nameTextField.setText("");
                        addressTextField.setText("");
                        phoneTextField.setText("");
                        emailTextField.setText("");
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // add labels, textfields and buttons to the input panel
        inputPanel.add(iDLabel);
        inputPanel.add(iDTextField);
        
        inputPanel.add(nameLabel);
        inputPanel.add(nameTextField);
      
        inputPanel.add(addressLabel);
        inputPanel.add(addressTextField);
       
        

        inputPanel.add(phoneLabel);
        inputPanel.add(phoneTextField);
        

        inputPanel.add(emailLabel);
        inputPanel.add(emailTextField);
      
        
        inputPanel.add(findButton);
        inputPanel.add(addButton);
        inputPanel.add(updateButton);
        inputPanel.add(deleteButton);
        // create panel for displaying data from the table
        JPanel dataPanel = new JPanel();
        dataPanel.setLayout(new BorderLayout());

        // create table for displaying data
        dataTable = new JTable();
        scrollPane = new JScrollPane(dataTable);
        dataPanel.add(scrollPane, BorderLayout.CENTER);

        // add input panel and data panel to the main frame
        add(inputPanel, BorderLayout.NORTH);
        add(dataPanel, BorderLayout.CENTER);

        // connect to database
        try {
            connection = DriverManager.getConnection(DATABASE_URL, "root", "");
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        // load data from the table into the JTable
        iDTextField.setText("");
        nameTextField.setText("");
        addressTextField.setText("");
        phoneTextField.setText("");
        emailTextField.setText("");

        setVisible(true);
    }


public static void main(String[] args) {
CRUDJCustomers app = new CRUDJCustomers();
}
}
       