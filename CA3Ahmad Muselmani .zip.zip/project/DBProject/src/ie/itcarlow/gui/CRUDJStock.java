package ie.itcarlow.gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class CRUDJStock extends JFrame {

    private JLabel iDLabel,  descriptionLabel, qtyLabel, reorderLabel, retailLabel, costLabel;
    private JTextField iDTextField, descriptionTextField, qtyTextField, reorderTextField, retailTextField, costTextField;
    private JButton findButton, addButton, updateButton, deleteButton;
    private JTable dataTable;
    private JScrollPane scrollPane;
    private Connection connection;
    private PreparedStatement pstat;
    private final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";

    public CRUDJStock() {
        super("CRUD Operations Stock Table");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 700);

        // create panel for input fields and buttons
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(8, 5, 10, 10)); // changed to 6 rows to include all labels and textfields

        // create labels and textfields for input
        iDLabel = new JLabel("Enter ID:");
        iDTextField = new JTextField();

        descriptionLabel = new JLabel("Description:");
        descriptionTextField = new JTextField();
        
        qtyLabel = new JLabel("Qty in Stock:");
        qtyTextField = new JTextField();
        
        reorderLabel = new JLabel("Reorder Level:");
        reorderTextField = new JTextField();

        retailLabel = new JLabel("Retail Price:");
        retailTextField = new JTextField();
        
        costLabel =  new JLabel("Cost Price:");
        costTextField=  new JTextField();

        // create buttons for CRUD operations
        findButton = new JButton("Find"); // fixed variable name, was addButton before
        findButton.setLocation(50, 50);
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        
        
     // create buttons for CRUD operations
        findButton = new JButton("Find");
        findButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    int id = Integer.parseInt(iDTextField.getText()); 
                    String query = "SELECT * FROM stock WHERE Stock_ID = ?";
                    pstat = connection.prepareStatement(query);
                    pstat.setInt(1, id);
                    ResultSet rs = pstat.executeQuery();
                    if (!rs.next()) {
                        JOptionPane.showMessageDialog(null, "Couldn't find the ID");
                    } else {
                    	descriptionTextField.setText(rs.getString("Description"));
                    	qtyTextField.setText(rs.getString("Quantity_In_Stock"));
                    	reorderTextField.setText(rs.getString("Reorder_Level"));
                    	retailTextField.setText(rs.getString("Retail_Price"));
                    	costTextField.setText(rs.getString("Cost_Price"));
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
        addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get the data from the input fields
                    String description = descriptionTextField.getText();
                    int qtyInStock = Integer.parseInt(qtyTextField.getText());
                    int reorderLevel = Integer.parseInt(reorderTextField.getText());
                    int retail = Integer.parseInt(retailTextField.getText());
                    int cost = Integer.parseInt(costTextField.getText());

                    // create Prepared Statement for inserting data into table
                    pstat = connection.prepareStatement("INSERT INTO stock (Description, Quantity_In_Stock, Reorder_Level, Retail_Price, Cost_Price) VALUES (?,?,?,?,?)");
                    
                    pstat.setString(1, description);
                    pstat.setInt(2, qtyInStock);
                    pstat.setInt(3, reorderLevel);
                    pstat.setInt(4, retail);
                    pstat.setInt(5, cost);
                    pstat.executeUpdate();

                    // Clear the input fields
                    
                    descriptionTextField.setText("");
                    qtyTextField.setText("");
                    reorderTextField.setText("");
                    retailTextField.setText("");
                    costTextField.setText("");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        
       
        updateButton = new JButton("Update");
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get the data from the input fields
                    int id = Integer.parseInt(iDTextField.getText()); 
                    String description = descriptionTextField.getText();
                    int qtyInStock = Integer.parseInt(qtyTextField.getText());
                    int reorderLevel = Integer.parseInt(reorderTextField.getText());
                    int retail = Integer.parseInt(retailTextField.getText());
                    int cost = Integer.parseInt(costTextField.getText());

                    // create Prepared Statement for updating data in table
                    pstat = connection.prepareStatement("UPDATE stock SET Description = ?, Quantity_In_Stock = ?, Reorder_Level = ?, Retail_Price = ?, Cost_Price = ? WHERE Stock_ID = ?");
                    
                    pstat.setString(1, description);
                    pstat.setInt(2, qtyInStock);
                    pstat.setInt(3, reorderLevel);
                    pstat.setInt(4, retail);
                    pstat.setInt(5, cost);
                    pstat.setInt(6, id);
                    
                    // execute the update statement
                    int rowsUpdated = pstat.executeUpdate();
                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(null, "Data has been updated successfully!");
                        // Clear the input fields
                        iDTextField.setText("");
                        descriptionTextField.setText("");
                        qtyTextField.setText("");
                        reorderTextField.setText("");
                        retailTextField.setText("");
                        costTextField.setText("");
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        
        
        deleteButton = new JButton("Delete");
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Get the ID from the input field
                	int id = Integer.parseInt(iDTextField.getText()); 

                    // create Prepared Statement for deleting data from table
                    pstat = connection.prepareStatement("DELETE FROM stock WHERE stock_ID = ?");
                    pstat.setInt(1, id);
                    pstat.executeUpdate();

                    // Clear the input fields
                    iDTextField.setText("");
                    descriptionTextField.setText("");
                    qtyTextField.setText("");
                    reorderTextField.setText("");
                    retailTextField.setText("");
                    costTextField.setText("");
                    
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

     // add the labels and textfields to the input panel
        inputPanel.add(iDLabel);
        inputPanel.add(iDTextField);

        inputPanel.add(descriptionLabel);
        inputPanel.add(descriptionTextField);

        inputPanel.add(qtyLabel);
        inputPanel.add(qtyTextField);

        inputPanel.add(reorderLabel);
        inputPanel.add(reorderTextField);

        inputPanel.add(retailLabel);
        inputPanel.add(retailTextField);

        inputPanel.add(costLabel);
        inputPanel.add(costTextField);

        // add the buttons to the input panel
        inputPanel.add(findButton);
        inputPanel.add(addButton);
        inputPanel.add(updateButton);
        inputPanel.add(deleteButton);

        // create a panel for the data table
        JPanel dataPanel = new JPanel(new GridLayout());
        DefaultTableModel model = new DefaultTableModel();
        dataTable = new JTable(model);
        model.addColumn("ID");
        model.addColumn("Description");
        model.addColumn("Qty in Stock");
        model.addColumn("Reorder Level");
        model.addColumn("Retail Price");
        model.addColumn("Cost Price");

        // create a scroll pane and add the data table to it
        scrollPane = new JScrollPane(dataTable);
        dataPanel.add(scrollPane);

        // add the input panel and data panel to the frame
        add(inputPanel, BorderLayout.NORTH);
        add(dataPanel, BorderLayout.CENTER);

        // connect to the database and populate the data table
        try {
            connection = DriverManager.getConnection(DATABASE_URL, "root", "");
            String query = "SELECT * FROM stock";
            pstat = connection.prepareStatement(query);
            ResultSet rs = pstat.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("Stock_ID");
                String description = rs.getString("Description");
                int qtyInStock = rs.getInt("Quantity_In_Stock");
                int reorderLevel = rs.getInt("Reorder_Level");
                int retail = rs.getInt("Retail_Price");
                int cost = rs.getInt("Cost_Price");

                model.addRow(new Object[]{id, description, qtyInStock, reorderLevel, retail, cost});
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        setVisible(true);
        
    }

    public static void main(String[] args) {
    	CRUDJStock crud = new CRUDJStock();
    }

}
