package ie.itcarlow.db;

import java . sql .Connection;
import java . sql .DriverManager;
import java . sql .PreparedStatement;
import java . sql .SQLException;

public class DeleteStock 
{

	public static void main(String [] args) 
	{
	// database URL
	final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";
	Connection connection = null;
	PreparedStatement pstat = null;
	int i=0;
	int stockID=4;
	try
	{
		// establish connection to database
		connection = DriverManager.getConnection(DATABASE_URL, "root", "" );
		
		// create Prepared Statement for deleting data from the table
		pstat = connection.prepareStatement("DELETE From stock WHERE Stock_ID=?" );
		pstat.setInt (1, stockID);
		
		// delete data from the table
		i = pstat.executeUpdate();
		System.out. println ( i + " record successfully removed from the table .");
	}
		catch(SQLException sqlException ) 
		{
			sqlException . printStackTrace () ;
		}
		finally 
		{
		try
		{
		pstat . close () ;
		connection. close () ;
		}
		catch ( Exception exception ){
		exception . printStackTrace () ;
		}
	}
	} // end main
} // end class
