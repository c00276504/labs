package ie.itcarlow.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Date;
import java.util.Calendar;

public class InsertOrder { 
    public static void main(String[] args) {
        final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";
        Connection connection = null;
        PreparedStatement pstat = null;
        int customerID = 2;
        String description = "Self winding Watch ";
        Calendar calendar = Calendar.getInstance();
        calendar.set(2023, 5, 2); // January 1, 2023
        Date orderDate = new Date(calendar.getTime().getTime()); 
        int quantity = 2;
        int i = 0;

        try {
            // establish connection to database
            connection = DriverManager.getConnection(DATABASE_URL, "root", "");
            // create Prepared Statement for inserting data into table
            pstat = connection.prepareStatement(
                    "INSERT INTO orders (Customer_ID, Description, Order_Date, Quantity) VALUES (?,?,?,?)");
            pstat.setInt(1, customerID);
            pstat.setString(2, description);
            pstat.setDate(3, orderDate);
            pstat.setInt(4, quantity);
            // insert data into table
            i = pstat.executeUpdate();
            System.out.println(i + " record successfully added to the table.");
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } finally {
            try {
                if (pstat != null) {
                    pstat.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
}