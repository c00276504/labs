package ie.itcarlow.db;

//Update an customer in the customers table .
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateStock
{
	public static void main(String [] args) 
	{
		//database URL
		final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";
		String description = "Self winding Watch";
		int id = 3;
		int qty = 30;
		int reorderLevel=10;
        int retailPrice = 120;
        int costPrice = 100;
		Connection connection = null;
		PreparedStatement pstat = null;
		int i=0;
		try
		{
			// establish connection to database
			connection = DriverManager.getConnection(DATABASE_URL, "root", "" );
			
			// create Prepared Statement for updating data in the table
			pstat = connection.prepareStatement("UPDATE stock SET Description=?,  Quantity_In_Stock=?, Reorder_Level=?,   Retail_Price=?, Cost_Price=? WHERE Stock_ID=? ");
			
			pstat.setString(1, description);
			pstat.setInt(2, qty);
			pstat.setInt(3, reorderLevel);
		    pstat.setInt(4, retailPrice);
		    pstat.setInt(5, costPrice);
		    pstat.setInt(6, id);
		    
		    
		    
			//Update data in the table
			i = pstat.executeUpdate();
			System.out. println ( i + " record successfully updated in the table .");
		}
		
		catch(SQLException sqlException ) 
		{
			sqlException . printStackTrace () ;
		}
		
		finally
		{
			
			try
			{
				pstat . close () ;
				connection. close () ;
			}
			catch ( Exception exception )
			{
				exception . printStackTrace () ;
			}
		}
	} // end main
} // end class
