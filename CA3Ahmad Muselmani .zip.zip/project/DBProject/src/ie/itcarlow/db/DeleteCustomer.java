package ie.itcarlow.db;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteCustomer {
    public static void main(String[] args) {
        // database URL
        final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";
        Connection connection = null;
        PreparedStatement pstat = null;
        int i = 0;
        int customerID = 1;
        try {
            // establish connection to database
            connection = DriverManager.getConnection(DATABASE_URL, "root", "");

            // create Prepared Statement for deleting data from the table
            pstat = connection.prepareStatement("DELETE From customers WHERE Customer_ID=?");
            pstat.setInt(1, customerID);

            // delete data from the table
            i = pstat.executeUpdate();
            System.out.println(i + " record successfully removed from the table.");
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } finally {
            try {
                if (pstat != null) {
                    pstat.close();
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }
            try {
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    } // end main
} // end class

