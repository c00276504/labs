package ie.itcarlow.db;

//Update an customer in the customers table .
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateCustomer 
{
	public static void main(String [] args) 
	{
		//database URL
		final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";
		int customerID = 1;
		String customerName = "Ahmad Muselmani";
		String address = "Carlow";
		String phoneNumber = "082321232";
		String email = "Ahmad@itcarlow.ie";
		Connection connection = null;
		PreparedStatement pstat = null;
		int i=0;
		try
		{
			// establish connection to database
			connection = DriverManager.getConnection(DATABASE_URL, "root", "" );
			
			// create Prepared Statement for updating data in the table
			pstat = connection.prepareStatement("UPDATE customers SET Customer_Name=?, Address=?, Phone_Number=?, Email=?  WHERE Customer_ID=? ");

		    
		   
		    pstat.setString(1, customerName);
		    pstat.setString(2, address);
		    pstat.setString(3, phoneNumber);
		    pstat.setString(4, email);
		    pstat.setInt(5, customerID);
		    
			//Update data in the table
			i = pstat.executeUpdate();
			System.out. println ( i + " record successfully updated in the table .");
		}
		
		catch(SQLException sqlException ) 
		{
			sqlException . printStackTrace () ;
		}
		
		finally
		{
			
			try
			{
				pstat . close () ;
				connection. close () ;
			}
			catch ( Exception exception )
			{
				exception . printStackTrace () ;
			}
		}
	} // end main
} // end class
