package ie.itcarlow.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertStock {
    public static void main(String[] args) {
        // database URL
        final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";
        Connection connection = null;
        PreparedStatement pstat = null;
        String description = "sunglasses";
        int quantityInStock = 25;
        int reorderLevel = 15;
        int retailPrice = 20;
        int costPrice = 15;
        int i = 0;

        try {
            // establish connection to database
            connection = DriverManager.getConnection(DATABASE_URL, "root", "");
            // create Prepared Statement for inserting data into table
            pstat = connection.prepareStatement(
                    "INSERT INTO stock (Description, Quantity_In_Stock, Reorder_Level, Retail_Price, Cost_Price) VALUES (?,?,?,?,?)");
            pstat.setString(1, description);
            pstat.setInt(2, quantityInStock);
            pstat.setInt(3, reorderLevel);
            pstat.setInt(4, retailPrice);
            pstat.setInt(5, costPrice);
            // insert data into table
            i = pstat.executeUpdate();
            System.out.println(i + " record successfully added to the table.");
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } finally {
            try {
                if (pstat != null) {
                    pstat.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
} 