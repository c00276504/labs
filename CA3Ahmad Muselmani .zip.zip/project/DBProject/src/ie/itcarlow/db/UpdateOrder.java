package ie.itcarlow.db;

//Update an customer in the Orders table .
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;

public class UpdateOrder 
{
	public static void main(String [] args) 
	{
		//database URL
		final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";
		 int orderID = 4; 
		 int customerID = 3;
	     String description = "2400W Hair Dryer";
	     Calendar calendar = Calendar.getInstance();
	     calendar.set(2023, 5, 2); // January 1, 2023
	     Date orderDate = new Date(calendar.getTime().getTime()); 
	     int quantity = 2;
	     
		Connection connection = null;
		PreparedStatement pstat = null;
		int i=0;
		try
		{
			// establish connection to database
			connection = DriverManager.getConnection(DATABASE_URL, "root", "" );
			
			// create Prepared Statement for updating data in the table
			pstat = connection.prepareStatement("UPDATE orders SETCustomer_ID=?, Description =?, Order_Date=?, Quantity=? WHERE  Order_ID =? ");

		   
		    pstat.setInt(1, customerID);
		    pstat.setString(2, description);
		    pstat.setDate(3, orderDate);
		    pstat.setInt(4, quantity);
		    pstat.setInt(5, orderID);
			//Update data in the table
			i = pstat.executeUpdate();
			System.out. println ( i + " record successfully updated in the table .");
		}
		
		catch(SQLException sqlException ) 
		{
			sqlException . printStackTrace () ;
		}
		
		finally
		{
			
			try
			{
				pstat . close () ;
				connection. close () ;
			}
			catch ( Exception exception )
			{
				exception . printStackTrace () ;
			}
		}
	} // end main
} // end class
