package ie.itcarlow.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InsertCustomer {
    public static void main(String[] args) {
        // database URL
        final String DATABASE_URL = "jdbc:mysql://localhost/customer_project";
        Connection connection = null;
        PreparedStatement pstat = null;
        String customerName = "Umar Said";
        String address = "Dublin";
        String phoneNumber = "0856658722";
        String email = "umar@itcarlow.ie";
        int i = 0;

        try {
            // establish connection to database
            connection = DriverManager.getConnection(DATABASE_URL, "root", "");
            // create Prepared Statement for inserting data into table
            pstat = connection.prepareStatement(
                    "INSERT INTO customers (Customer_Name, Address, Phone_Number, Email) VALUES (?,?,?,?)");
            pstat.setString(1, customerName);
            pstat.setString(2, address);
            pstat.setString(3, phoneNumber);
            pstat.setString(4, email);
            // insert data into table
            i = pstat.executeUpdate();
            System.out.println(i + " record successfully added to the table.");
        } catch (SQLException sqlException) {
            sqlException.printStackTrace();
        } finally {
            try {
                if (pstat != null) {
                    pstat.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
} 
